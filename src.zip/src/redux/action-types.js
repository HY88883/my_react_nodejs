export const UPDATECOMMENT = 'updateComment'
export const DELETECOMMENT = 'deleteComment'
export const RECEIVECOMMENT = 'receiveComment'

