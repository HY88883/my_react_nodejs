import React, {Component} from "react"
import propTypes from 'prop-types'
import {connect} from 'react-redux'

import CommentAdd from "../../components/comment-add/comment-add"
import CommentList from "../../components/comment-list/comment-list"
import {asyncGetComments,updateComment,deleteComment} from '../../redux/action-creators'
class App extends Component {

    static propTypes = {
        comments: propTypes.array.isRequired,
        updateComment: propTypes.func.isRequired,
        deleteComment: propTypes.func.isRequired,
        asyncGetComments: propTypes.func.isRequired,
    }
    componentDidMount() {
        this.props.asyncGetComments()
    }

    render () {
        const {updateComment,deleteComment,comments} = this.props
        return(
            <div id="app">
                <div>
                    <header className="site-header jumbotron">
                        <div className="container">
                            <div className="row">
                                <div className="col-xs-12">
                                    <h1>请发表对React的评论</h1>
                                </div>
                            </div>
                        </div>
                    </header>
                    <div className="container">
                    <CommentAdd updateComment={updateComment}/>
                    <CommentList comments={comments} deleteComment={deleteComment}/>
                    </div>
                </div>
            </div>
        )
    }
}

export default connect(
    state =>({comments:state}),
    {updateComment,deleteComment,asyncGetComments}
)(Component)
